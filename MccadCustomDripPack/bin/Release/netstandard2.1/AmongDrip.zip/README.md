Recommended for rundown dev use only. Using this in a lobby with someone who doesnt have this plugin installed may cause issues

Generates "mccad00/CustomPalettes.json" which allows rundown devs to configure custom player color palettes.
Includes an empty option for the backpack and helmet slot

## tone texture settings:

None = 0                Flat color

Plaid = 1               Pink plaid checkerboard pattern

CamoLarge1 = 2          Large diffuse blob-shaped color gradients

PaintSplash = 3         Sharp bright splash of color

Scanlines = 4           Medium sized repeating stripe pattern

GradientStripes = 5     Large sized repeating colored gradient pattern

Cortex = 6              Large red and green nueral interface pattern

DustedPaint = 7         Black with dusty colored highlights on some surfaces

Polkadots1 = 8          Large diffuse repeating dot pattern

BigStainedGlass = 9     Large polygonal multicolored pattern

TinyDust = 10           Black with a sublte pattern of tiny specks

HeatGradient = 11       Large red and yellow gradient

Pizza = 12              Red with a repeating pattern of large off white circles

Fireballs = 13          Black with a repeating pattern of red fireballs

Scales = 14             Subtle red colored scale relief pattern

SmallStainedGlass = 15  Bright green filled polygon pattern with red circles

CamoLarge2 = 16         Large diffuse blob-shaped color gradients

BlueGreenDots = 17      Bright cyan with small repeating green dots

BlueRedPattern = 18     Fashionable blue and cyan pattern with maroon stripes

GreenBluePattern = 19   Black with large bright green splotches and subtle blue shapes

SubtleGradient = 20     Subtle color gradient from black to your selected color

Stripes = 21            Repeating pattern of small stripes

GokuDrip = 22           By Any Means Necessary

Emoji = 23              Who did this

WoodlandCamo = 24       Custom camo texture

AlpineCamo = 25         Custom camo texture

DigitalCamo = 26        Custom camo texture

Anime = 27              Ahegao pattern